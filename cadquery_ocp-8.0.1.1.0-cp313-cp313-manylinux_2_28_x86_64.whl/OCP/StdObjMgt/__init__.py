from ..OCP.StdObjMgt import *
