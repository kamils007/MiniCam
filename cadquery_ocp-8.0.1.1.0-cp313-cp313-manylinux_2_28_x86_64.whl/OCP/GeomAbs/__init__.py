from ..OCP.GeomAbs import *
