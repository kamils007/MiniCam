from ..OCP.GProp import *
