from ..OCP.TDocStd import *
