from ..OCP.Message import *
