from ..OCP.IGESData import *
