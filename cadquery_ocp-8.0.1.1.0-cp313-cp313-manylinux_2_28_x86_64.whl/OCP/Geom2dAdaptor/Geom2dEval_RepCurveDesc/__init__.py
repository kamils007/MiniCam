from ..OCP.Geom2dAdaptor.Geom2dEval_RepCurveDesc import *
