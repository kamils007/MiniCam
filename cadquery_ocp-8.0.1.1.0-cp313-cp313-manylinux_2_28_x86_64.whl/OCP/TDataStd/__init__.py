from ..OCP.TDataStd import *
