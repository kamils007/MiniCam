from ..OCP.IntPolyh import *
