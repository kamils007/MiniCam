from ..OCP.IGESSolid import *
