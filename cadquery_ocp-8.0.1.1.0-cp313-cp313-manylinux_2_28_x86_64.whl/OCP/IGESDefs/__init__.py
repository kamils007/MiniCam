from ..OCP.IGESDefs import *
