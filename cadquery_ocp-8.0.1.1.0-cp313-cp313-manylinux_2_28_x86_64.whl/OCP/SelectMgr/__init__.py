from ..OCP.SelectMgr import *
