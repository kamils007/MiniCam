from ..OCP.TopoDS.TopoDS import *
