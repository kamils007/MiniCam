from ..OCP.HLRAlgo import *
