from ..OCP.TopAbs import *
