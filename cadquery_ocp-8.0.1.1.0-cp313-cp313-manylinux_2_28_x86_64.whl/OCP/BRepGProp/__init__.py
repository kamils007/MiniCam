from ..OCP.BRepGProp import *
