from ..OCP.GeomAPI import *
