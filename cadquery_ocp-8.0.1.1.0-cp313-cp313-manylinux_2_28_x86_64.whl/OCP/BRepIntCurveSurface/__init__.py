from ..OCP.BRepIntCurveSurface import *
