from ..OCP.GeomAdaptor.GeomEval_RepCurveDesc import *
