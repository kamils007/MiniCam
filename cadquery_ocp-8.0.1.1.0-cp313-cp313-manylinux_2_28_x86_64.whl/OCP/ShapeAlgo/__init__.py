from ..OCP.ShapeAlgo import *
