from ..OCP.NCollection.NCollection_PackedMapAlgo import *
