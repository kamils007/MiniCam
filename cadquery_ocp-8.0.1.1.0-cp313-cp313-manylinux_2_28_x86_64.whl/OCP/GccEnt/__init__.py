from ..OCP.GccEnt import *
